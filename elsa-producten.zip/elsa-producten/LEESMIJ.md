# Elsa's Kapsalon — productbeelden

Zeven fictieve producten voor het portfolio van Elsa's Kapsalon.

## Bestanden

- PNG: originele afbeeldingen, 1254 × 1254 pixels.
- web/*.jpg: lichtere afbeeldingen voor je webshop, 1200 × 1200 pixels.
- prompts.md: de complete prompts, gemaakt met de ingebouwde imagegen-tool.

- 01-luxe-gel.png / web/01-luxe-gel.jpg
- 02-mineralen-shampoo.png / web/02-mineralen-shampoo.jpg
- 03-droogshampoo.png / web/03-droogshampoo.jpg
- 04-haarlak.png / web/04-haarlak.jpg
- 05-gezichtscreme.png / web/05-gezichtscreme.jpg
- 06-baardolie.png / web/06-baardolie.jpg
- 07-haarolie.png / web/07-haarolie.jpg

## Ontwerp

Mat chocoladebruin, champagnegouden details en warme ivoorkleurige letters. Een rond E-monogram met een botanisch takje en het woordmerk Elsa's Kapsalon verbindt alle verpakkingen. Donkere espressoachtergrond, centraal product en warm licht van linksboven. Kleuren en klassieke typografie sluiten aan op de bestaande website.

De ingrediënten en verzorgende productbeschrijvingen zijn fictieve concepten voor dit portfolio.
