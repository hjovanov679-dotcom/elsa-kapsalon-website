# Elsa's Kapsalon — definitieve beeldprompts

Gemaakt met de ingebouwde imagegen-tool (geen CLI/API-fallback).
De mineralenshampoo vormde de visuele referentie voor de zes overige beelden.

## 01 — luxe-gel

Use case: product-mockup.
Asset type: one standalone square ecommerce product photograph for the fictional Dutch luxury salon brand Elsa's Kapsalon.
Art direction: refined classic European apothecary meets contemporary salon luxury. Coherent brand palette from the actual website: near-black espresso #1D1917, warm taupe #A58F7C, muted champagne gold #C8AD7F, pale warm cream #D8C9B8. The packaging itself is always rich dark walnut/chocolate BROWN, never black, with satin matte tactile finish, small brushed champagne gold metal accents and ivory/gold printing.
Shared brand identity: a thin circular champagne gold seal with an elegant serif capital E and a tiny botanical leaf, with the highly legible wordmark "Elsa's" in a refined high-contrast serif inspired by Cormorant Garamond immediately below and "KAPSALON" in small tracked uppercase underneath. Centered aligned label grid, fine restrained gold divider, plenty of air, no ornamental overload. Use exactly the same logo on all products.
Composition: square 1:1 image, one single product perfectly centered horizontally, complete silhouette visible, upright facing camera with just enough elevated view to see the top. Product alone, with generous breathing room and readable front label. Camera 85mm commercial product lens, photorealistic professionally retouched premium cosmetic still life, fine realistic material detail.
Background and lighting: seamless dark espresso brown studio background #1D1917 with subtle soft warm halo directly behind subject, darker vignetted corners, a dark brown matte stone floor fading into backdrop without horizon line. Soft warm directional key light upper left, delicate rim highlight right separating brown silhouette from background, graceful real soft shadow to lower right, no harsh spotlight, very restrained reflection. Maintain brightness enough to clearly see the brown packaging and read label.
Healthy/caring character comes from the botanical monogram and understated ingredient label, not medical claims. No people, hands, added props, floating particles, splashing water, plants around the product, carton boxes, extra containers, watermarks, banners, price tags, certification seals or text outside the product. No collage. All lettering must be clean, correct and physically printed onto the product.
Input image 1 role: strict visual brand and lighting reference, the already approved mineral shampoo from this same product family. Create a DIFFERENT standalone product, while preserving exactly the reference's circular E-and-botanical-twig logo, Elsa's KAPSALON wordmark, typography, warm brown materials, printed gold/ivory colors, background, camera direction and lighting. Adapt packaging proportions and label text to the new product only. This should look shot in the same studio on the same day. The monogram and wordmark must remain unmistakably identical to the reference.
Subject for THIS image: premium caring styling gel in a substantial wide, squat cylinder jar with satin walnut/chocolate-brown body, flat matching brown screw lid with a fine brushed gold band at its base. Front body is tall enough for legible label. Closed jar, no gel visible. Jar occupies about 61 percent image width and 57 percent image height, centered with base at 84 percent image height.
Exact front label in order from top to bottom:
[Same circular E botanical logo as reference]
"Elsa's"
"KAPSALON"
[Same short fine gold divider]
"STYLING GEL"
"Aloë vera · Panthenol"
"Verzorgende hold"
"100 ml"
Only this product and this text, no shampoo text. Keep a large legible product name. Generate a single square final photo.

## 02 — mineralen-shampoo

Use case: product-mockup.
Asset type: one standalone square ecommerce product photograph for the fictional Dutch luxury salon brand Elsa's Kapsalon.
Art direction: refined classic European apothecary meets contemporary salon luxury. Coherent brand palette from the actual website: near-black espresso #1D1917, warm taupe #A58F7C, muted champagne gold #C8AD7F, pale warm cream #D8C9B8. The packaging itself is always rich dark walnut/chocolate BROWN, never black, with satin matte tactile finish, small brushed champagne gold metal accents and ivory/gold printing.
Shared brand identity: a thin circular champagne gold seal with an elegant serif capital E and a tiny botanical leaf, with the highly legible wordmark "Elsa's" in a refined high-contrast serif inspired by Cormorant Garamond immediately below and "KAPSALON" in small tracked uppercase underneath. Centered aligned label grid, fine restrained gold divider, plenty of air, no ornamental overload. Use exactly the same logo on all products.
Composition: square 1:1 image, one single product perfectly centered horizontally, complete silhouette visible, upright facing camera with just enough elevated view to see the top. Product alone, with generous breathing room and readable front label. Camera 85mm commercial product lens, photorealistic professionally retouched premium cosmetic still life, fine realistic material detail.
Background and lighting: seamless dark espresso brown studio background #1D1917 with subtle soft warm halo directly behind subject, darker vignetted corners, a dark brown matte stone floor fading into backdrop without horizon line. Soft warm directional key light upper left, delicate rim highlight right separating brown silhouette from background, graceful real soft shadow to lower right, no harsh spotlight, very restrained reflection. Maintain brightness enough to clearly see the brown packaging and read label.
Healthy/caring character comes from the botanical monogram and understated ingredient label, not medical claims. No people, hands, added props, floating particles, splashing water, plants around the product, carton boxes, extra containers, watermarks, banners, price tags, certification seals or text outside the product. No collage. All lettering must be clean, correct and physically printed onto the product.
Subject for this image: premium mineral shampoo, 250 ml. A substantial rounded cylindrical satin walnut-brown bottle with gently sloping shoulders, dark brown precision pump and a narrow brushed champagne gold neck ring. The pump is closed and points sideways. The bottle takes up approximately 72 percent of the image height and 34 percent width, base at 84 percent image height. Classic luxury beauty product hero photograph.
Exact front label text in order, each on its own line, from top to bottom:
[E botanical circle logo]
"Elsa's"
"KAPSALON"
[thin divider]
"MINERALEN"
"SHAMPOO"
"Magnesium · Zink"
"Milde verzorging"
"250 ml"
Brand wordmark is prominent and product name is clearly readable. Do not add other text. Generate the final individual product image, not a layout or moodboard.

## 03 — droogshampoo

Use case: product-mockup.
Asset type: one standalone square ecommerce product photograph for the fictional Dutch luxury salon brand Elsa's Kapsalon.
Art direction: refined classic European apothecary meets contemporary salon luxury. Coherent brand palette from the actual website: near-black espresso #1D1917, warm taupe #A58F7C, muted champagne gold #C8AD7F, pale warm cream #D8C9B8. The packaging itself is always rich dark walnut/chocolate BROWN, never black, with satin matte tactile finish, small brushed champagne gold metal accents and ivory/gold printing.
Shared brand identity: a thin circular champagne gold seal with an elegant serif capital E and a tiny botanical leaf, with the highly legible wordmark "Elsa's" in a refined high-contrast serif inspired by Cormorant Garamond immediately below and "KAPSALON" in small tracked uppercase underneath. Centered aligned label grid, fine restrained gold divider, plenty of air, no ornamental overload. Use exactly the same logo on all products.
Composition: square 1:1 image, one single product perfectly centered horizontally, complete silhouette visible, upright facing camera with just enough elevated view to see the top. Product alone, with generous breathing room and readable front label. Camera 85mm commercial product lens, photorealistic professionally retouched premium cosmetic still life, fine realistic material detail.
Background and lighting: seamless dark espresso brown studio background #1D1917 with subtle soft warm halo directly behind subject, darker vignetted corners, a dark brown matte stone floor fading into backdrop without horizon line. Soft warm directional key light upper left, delicate rim highlight right separating brown silhouette from background, graceful real soft shadow to lower right, no harsh spotlight, very restrained reflection. Maintain brightness enough to clearly see the brown packaging and read label.
Healthy/caring character comes from the botanical monogram and understated ingredient label, not medical claims. No people, hands, added props, floating particles, splashing water, plants around the product, carton boxes, extra containers, watermarks, banners, price tags, certification seals or text outside the product. No collage. All lettering must be clean, correct and physically printed onto the product.
Input image 1 role: strict visual brand and lighting reference, the already approved mineral shampoo from this same product family. Create a DIFFERENT standalone product, while preserving exactly the reference's circular E-and-botanical-twig logo, Elsa's KAPSALON wordmark, typography, warm brown materials, printed gold/ivory colors, background, camera direction and lighting. Adapt packaging proportions and label text to the new product only. This should look shot in the same studio on the same day. The monogram and wordmark must remain unmistakably identical to the reference.
Subject for THIS image: premium dry shampoo in a slim tall cylindrical satin walnut/chocolate-brown aerosol bottle with a matching flush brown overcap and a narrow brushed gold ring at the cap base. Closed cap, no spray visible. Product about 74 percent image height and 29 percent image width, base at 86 percent image height.
Exact front label in order from top to bottom:
[Same circular E botanical logo as reference]
"Elsa's"
"KAPSALON"
[Same short fine gold divider]
"DROOGSHAMPOO"
"Rijstzetmeel"
"Fris & luchtig"
"200 ml"
Only this product and this text, no shampoo text. Keep a large legible product name. Generate a single square final photo.

## 04 — haarlak

Use case: product-mockup.
Asset type: one standalone square ecommerce product photograph for the fictional Dutch luxury salon brand Elsa's Kapsalon.
Art direction: refined classic European apothecary meets contemporary salon luxury. Coherent brand palette from the actual website: near-black espresso #1D1917, warm taupe #A58F7C, muted champagne gold #C8AD7F, pale warm cream #D8C9B8. The packaging itself is always rich dark walnut/chocolate BROWN, never black, with satin matte tactile finish, small brushed champagne gold metal accents and ivory/gold printing.
Shared brand identity: a thin circular champagne gold seal with an elegant serif capital E and a tiny botanical leaf, with the highly legible wordmark "Elsa's" in a refined high-contrast serif inspired by Cormorant Garamond immediately below and "KAPSALON" in small tracked uppercase underneath. Centered aligned label grid, fine restrained gold divider, plenty of air, no ornamental overload. Use exactly the same logo on all products.
Composition: square 1:1 image, one single product perfectly centered horizontally, complete silhouette visible, upright facing camera with just enough elevated view to see the top. Product alone, with generous breathing room and readable front label. Camera 85mm commercial product lens, photorealistic professionally retouched premium cosmetic still life, fine realistic material detail.
Background and lighting: seamless dark espresso brown studio background #1D1917 with subtle soft warm halo directly behind subject, darker vignetted corners, a dark brown matte stone floor fading into backdrop without horizon line. Soft warm directional key light upper left, delicate rim highlight right separating brown silhouette from background, graceful real soft shadow to lower right, no harsh spotlight, very restrained reflection. Maintain brightness enough to clearly see the brown packaging and read label.
Healthy/caring character comes from the botanical monogram and understated ingredient label, not medical claims. No people, hands, added props, floating particles, splashing water, plants around the product, carton boxes, extra containers, watermarks, banners, price tags, certification seals or text outside the product. No collage. All lettering must be clean, correct and physically printed onto the product.
Input image 1 role: strict visual brand and lighting reference, the already approved mineral shampoo from this same product family. Create a DIFFERENT standalone product, while preserving exactly the reference's circular E-and-botanical-twig logo, Elsa's KAPSALON wordmark, typography, warm brown materials, printed gold/ivory colors, background, camera direction and lighting. Adapt packaging proportions and label text to the new product only. This should look shot in the same studio on the same day. The monogram and wordmark must remain unmistakably identical to the reference.
Subject for THIS image: premium caring hairspray in an elegant tall cylindrical satin walnut/chocolate-brown spray bottle, slightly taller and narrower than dry shampoo, with an exposed small precision dark brown spray actuator above a short brushed gold collar. No cap and no spray plume. Product about 76 percent image height and 28 percent image width, base at 86 percent image height.
Exact front label in order from top to bottom:
[Same circular E botanical logo as reference]
"Elsa's"
"KAPSALON"
[Same short fine gold divider]
"HAARLAK"
"Panthenol"
"Flexibele hold"
"250 ml"
Only this product and this text, no shampoo text. Keep a large legible product name. Generate a single square final photo.

## 05 — gezichtscreme

Use case: product-mockup.
Asset type: one standalone square ecommerce product photograph for the fictional Dutch luxury salon brand Elsa's Kapsalon.
Art direction: refined classic European apothecary meets contemporary salon luxury. Coherent brand palette from the actual website: near-black espresso #1D1917, warm taupe #A58F7C, muted champagne gold #C8AD7F, pale warm cream #D8C9B8. The packaging itself is always rich dark walnut/chocolate BROWN, never black, with satin matte tactile finish, small brushed champagne gold metal accents and ivory/gold printing.
Shared brand identity: a thin circular champagne gold seal with an elegant serif capital E and a tiny botanical leaf, with the highly legible wordmark "Elsa's" in a refined high-contrast serif inspired by Cormorant Garamond immediately below and "KAPSALON" in small tracked uppercase underneath. Centered aligned label grid, fine restrained gold divider, plenty of air, no ornamental overload. Use exactly the same logo on all products.
Composition: square 1:1 image, one single product perfectly centered horizontally, complete silhouette visible, upright facing camera with just enough elevated view to see the top. Product alone, with generous breathing room and readable front label. Camera 85mm commercial product lens, photorealistic professionally retouched premium cosmetic still life, fine realistic material detail.
Background and lighting: seamless dark espresso brown studio background #1D1917 with subtle soft warm halo directly behind subject, darker vignetted corners, a dark brown matte stone floor fading into backdrop without horizon line. Soft warm directional key light upper left, delicate rim highlight right separating brown silhouette from background, graceful real soft shadow to lower right, no harsh spotlight, very restrained reflection. Maintain brightness enough to clearly see the brown packaging and read label.
Healthy/caring character comes from the botanical monogram and understated ingredient label, not medical claims. No people, hands, added props, floating particles, splashing water, plants around the product, carton boxes, extra containers, watermarks, banners, price tags, certification seals or text outside the product. No collage. All lettering must be clean, correct and physically printed onto the product.
Input image 1 role: strict visual brand and lighting reference, the already approved mineral shampoo from this same product family. Create a DIFFERENT standalone product, while preserving exactly the reference's circular E-and-botanical-twig logo, Elsa's KAPSALON wordmark, typography, warm brown materials, printed gold/ivory colors, background, camera direction and lighting. Adapt packaging proportions and label text to the new product only. This should look shot in the same studio on the same day. The monogram and wordmark must remain unmistakably identical to the reference.
Subject for THIS image: premium hydrating face cream in an elegant thick-walled low rounded satin walnut/chocolate-brown cosmetic jar, luxurious matching domed brown lid edged by a fine brushed champagne gold band. Distinguish from hair gel with rounder shoulders and curved domed lid. Closed jar, no cream visible. Jar approximately 53 percent image width, 51 percent image height, base at 80 percent image height; substantial label area.
Exact front label in order from top to bottom:
[Same circular E botanical logo as reference]
"Elsa's"
"KAPSALON"
[Same short fine gold divider]
"GEZICHTSCRÈME"
"Hyaluron · Aloë vera"
"Hydraterend"
"50 ml"
Only this product and this text, no shampoo text. Keep a large legible product name. Generate a single square final photo.

## 06 — baardolie

Use case: product-mockup.
Asset type: one standalone square ecommerce product photograph for the fictional Dutch luxury salon brand Elsa's Kapsalon.
Art direction: refined classic European apothecary meets contemporary salon luxury. Coherent brand palette from the actual website: near-black espresso #1D1917, warm taupe #A58F7C, muted champagne gold #C8AD7F, pale warm cream #D8C9B8. The packaging itself is always rich dark walnut/chocolate BROWN, never black, with satin matte tactile finish, small brushed champagne gold metal accents and ivory/gold printing.
Shared brand identity: a thin circular champagne gold seal with an elegant serif capital E and a tiny botanical leaf, with the highly legible wordmark "Elsa's" in a refined high-contrast serif inspired by Cormorant Garamond immediately below and "KAPSALON" in small tracked uppercase underneath. Centered aligned label grid, fine restrained gold divider, plenty of air, no ornamental overload. Use exactly the same logo on all products.
Composition: square 1:1 image, one single product perfectly centered horizontally, complete silhouette visible, upright facing camera with just enough elevated view to see the top. Product alone, with generous breathing room and readable front label. Camera 85mm commercial product lens, photorealistic professionally retouched premium cosmetic still life, fine realistic material detail.
Background and lighting: seamless dark espresso brown studio background #1D1917 with subtle soft warm halo directly behind subject, darker vignetted corners, a dark brown matte stone floor fading into backdrop without horizon line. Soft warm directional key light upper left, delicate rim highlight right separating brown silhouette from background, graceful real soft shadow to lower right, no harsh spotlight, very restrained reflection. Maintain brightness enough to clearly see the brown packaging and read label.
Healthy/caring character comes from the botanical monogram and understated ingredient label, not medical claims. No people, hands, added props, floating particles, splashing water, plants around the product, carton boxes, extra containers, watermarks, banners, price tags, certification seals or text outside the product. No collage. All lettering must be clean, correct and physically printed onto the product.
Input image 1 role: strict visual brand and lighting reference, the already approved mineral shampoo from this same product family. Create a DIFFERENT standalone product, while preserving exactly the reference's circular E-and-botanical-twig logo, Elsa's KAPSALON wordmark, typography, warm brown materials, printed gold/ivory colors, background, camera direction and lighting. Adapt packaging proportions and label text to the new product only. This should look shot in the same studio on the same day. The monogram and wordmark must remain unmistakably identical to the reference.
Subject for THIS image: premium nourishing beard oil in a small rounded cylindrical frosted deep amber/chocolate brown glass dropper bottle, satin brown body matching reference, dark chocolate brown rubber pipette bulb on a brushed champagne gold collar. Closed bottle and upright pipette. Product about 66 percent image height and 33 percent image width, base at 83 percent image height.
Exact front label in order from top to bottom:
[Same circular E botanical logo as reference]
"Elsa's"
"KAPSALON"
[Same short fine gold divider]
"BAARDOLIE"
"Jojoba · Vitamine E"
"Voedende verzorging"
"30 ml"
Only this product and this text, no shampoo text. Keep a large legible product name. Generate a single square final photo.

## 07 — haarolie

Use case: product-mockup.
Asset type: one standalone square ecommerce product photograph for the fictional Dutch luxury salon brand Elsa's Kapsalon.
Art direction: refined classic European apothecary meets contemporary salon luxury. Coherent brand palette from the actual website: near-black espresso #1D1917, warm taupe #A58F7C, muted champagne gold #C8AD7F, pale warm cream #D8C9B8. The packaging itself is always rich dark walnut/chocolate BROWN, never black, with satin matte tactile finish, small brushed champagne gold metal accents and ivory/gold printing.
Shared brand identity: a thin circular champagne gold seal with an elegant serif capital E and a tiny botanical leaf, with the highly legible wordmark "Elsa's" in a refined high-contrast serif inspired by Cormorant Garamond immediately below and "KAPSALON" in small tracked uppercase underneath. Centered aligned label grid, fine restrained gold divider, plenty of air, no ornamental overload. Use exactly the same logo on all products.
Composition: square 1:1 image, one single product perfectly centered horizontally, complete silhouette visible, upright facing camera with just enough elevated view to see the top. Product alone, with generous breathing room and readable front label. Camera 85mm commercial product lens, photorealistic professionally retouched premium cosmetic still life, fine realistic material detail.
Background and lighting: seamless dark espresso brown studio background #1D1917 with subtle soft warm halo directly behind subject, darker vignetted corners, a dark brown matte stone floor fading into backdrop without horizon line. Soft warm directional key light upper left, delicate rim highlight right separating brown silhouette from background, graceful real soft shadow to lower right, no harsh spotlight, very restrained reflection. Maintain brightness enough to clearly see the brown packaging and read label.
Healthy/caring character comes from the botanical monogram and understated ingredient label, not medical claims. No people, hands, added props, floating particles, splashing water, plants around the product, carton boxes, extra containers, watermarks, banners, price tags, certification seals or text outside the product. No collage. All lettering must be clean, correct and physically printed onto the product.
Input image 1 role: strict visual brand and lighting reference, the already approved mineral shampoo from this same product family. Create a DIFFERENT standalone product, while preserving exactly the reference's circular E-and-botanical-twig logo, Elsa's KAPSALON wordmark, typography, warm brown materials, printed gold/ivory colors, background, camera direction and lighting. Adapt packaging proportions and label text to the new product only. This should look shot in the same studio on the same day. The monogram and wordmark must remain unmistakably identical to the reference.
Subject for THIS image: premium nourishing hair oil in a slender rounded-shoulder cylindrical frosted deep amber/chocolate brown glass bottle with a dark brown small precision dispensing pump and a fine champagne gold pump collar. Satin brown body matching reference, faint amber translucency only along bottom edges. Closed bottle, no droplets. Product about 72 percent image height and 32 percent image width, base at 85 percent image height.
Exact front label in order from top to bottom:
[Same circular E botanical logo as reference]
"Elsa's"
"KAPSALON"
[Same short fine gold divider]
"HAAROLIE"
"Argan · Camelia"
"Zijdezachte glans"
"50 ml"
Only this product and this text, no shampoo text. Keep a large legible product name. Generate a single square final photo.
